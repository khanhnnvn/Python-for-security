KeyLogger
===========

Keylogger is a type of surveillance software (considered to be either software or spyware)
that has the capability to record every keystroke you make to a log file, usually encrypted.
A keylogger recorder can record instant messages, e-mail, and any information you type at any time using your keyboard.
The log file created by the keylogger can then be sent to a specified receiver.
Some keylogger programs will also record any e-mail addresses you use and Web site URLs you visit.
Keyloggers, as a surveillance tool,
are often used by employers to ensureemployees use work computers for business purposes only.
this keylogger captures the screen when the screen was a significant change, and save the keyboards

Requirements:
===============
###Windows Installation:
1. Install [PIL](http://www.lfd.uci.edu/~gohlke/pythonlibs/#pillow)
2. Install [pyHook](http://www.lfd.uci.edu/~gohlke/pythonlibs/#pyhook)
3. Open Command Prompt(cmd) as Administrator -> Goto python folder -> Scripts (cd c:\Python27\Scripts)
4. pip install -r (Full Path To requirements.txt)
